<?
/**
 * utility/version.php
 * 
 * バージョンの表示
 */
?>
PHP Framework Samurai extends Maple3.
Version: <?=$version?>

Copyright (C) 2007-2010 Samurai Framework Project. All Rights Reserved.
  KIUCHI Satoshinosuke <scholar@hayabusa-lab.jp>


