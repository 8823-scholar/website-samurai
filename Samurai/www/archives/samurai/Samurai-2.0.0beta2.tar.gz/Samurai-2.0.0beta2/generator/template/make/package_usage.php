<?php
/**
 * make/package_usage.php
 * 
 * make-package::usage
 */
?>
Usage:
    samurai make-package [options]
Options:
    --usage  -[uU]          Show usage.
    --state=[state]         stable | beta | alpha
    --postfix=[postfix]     version postfix
    --make                  make package (don't debug)

