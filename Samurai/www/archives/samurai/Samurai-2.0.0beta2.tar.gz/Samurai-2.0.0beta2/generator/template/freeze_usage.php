<?php
/**
 * freeze_usage.php
 * 
 * freezeコマンドのUsage。
 */
?>
Explain:
    Freeze SamuraiFW version for application.
    
Usage:
    samurai freeze [command-option]
    
Options:
    --usage,   -[hH] Print this help and exit successfully.


