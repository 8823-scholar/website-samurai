#
# URLRouting用設定ファイル
#
# URLルーティングを行いたい場合は、ここに条件を記述してください。
#
# example
# <code>
#     alias:
#         url   : '/example/:id/show.html'
#         param : { action : 'example_friend_show' }
#         requirements : { id : '^\d+$' }
# </code>

