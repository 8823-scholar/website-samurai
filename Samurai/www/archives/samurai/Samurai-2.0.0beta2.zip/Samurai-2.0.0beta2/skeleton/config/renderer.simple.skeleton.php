<?php echo "<?php\n" ?>
/**
 * Simple用の初期化スクリプト
 * 
 * @package    <?php echo $package != '' ? $package . "\n" : "[[パッケージ名]]\n" ?>
 * @subpackage Config.Renderer
<?php include(dirname(dirname(__FILE__)) . '/_doc_comment.skeleton.php'); ?>
 */
//Helper
//$this->addHelper('Foo', array('class'=>'Helper_Simple_Foo'));

