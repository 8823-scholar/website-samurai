<?php
/**
 * migrate_db_usage.php
 * 
 * migrate_dbコマンドのUsage。
 */
?>
Explain:
    Migration 4 db.
    
Usage:
    samurai migrate-db [options]
    
Options:
    --usage,   -[hH] Print this help and exit successfully.
    --to=[version]   migrate to target version.


