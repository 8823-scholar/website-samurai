<?php
/**
 * error/command.tpl
 * 
 * コマンドエラー
 */
?>
No Such Command !!

Usage:
    samurai --usage

