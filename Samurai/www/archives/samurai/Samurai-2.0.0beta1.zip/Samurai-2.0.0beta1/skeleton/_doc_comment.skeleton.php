<?php if(isset($copyright) && $copyright != ''){ ?>
 * @copyright  <?php echo $copyright . "\n" ?>
<?php } ?>
<?php if(isset($author) && $author != ''){ ?>
 * @author     <?php echo $author . "\n" ?>
<?php } ?>
<?php if(isset($license) && $license != ''){ ?>
 * @license    <?php echo $license . "\n" ?>
<?php } ?>
