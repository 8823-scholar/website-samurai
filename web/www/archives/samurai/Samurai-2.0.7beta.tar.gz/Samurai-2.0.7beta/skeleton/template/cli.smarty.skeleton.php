{**
 * <?php echo join(' - ', $template_names)."\n" ?>
 *}
Usage:
    
Options:
    
